package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

public class Employe {
    @Id
    private  Integer id;
    private  String  name;
    private  String  address;
    private  Long phoneno;
    private  String  mail;
    public Employe()
    {

    }
    public Employe(Integer id,String name,String address,Long phoneno,String mail)
    {
        this.id=id;
        this.name=name;
        this.address=address;
        this.phoneno=phoneno;
        this.mail=mail;
    }

    public  Long getphone()
    {
        return phoneno;
    }

    public String getmail()
    {
        return  mail;
    }

    public String getname()
    {
        return name;
    }

    public  String getAddress()
    {
        return  address;
    }
   public int getid()
   {
       return id;
   }


}
