package com.example.demo.runner;

import com.example.demo.entity.Employe;
import com.example.demo.repository.EmployeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyRunner implements CommandLineRunner {
    @Autowired
    private EmployeRepository obj;

    @Override
    public void run(String... args) throws Exception
    {
        obj.save( new Employe(10,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(20,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(30,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(40,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(50,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(60,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(70,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
        obj.save( new Employe(80,"Shivam","23/43 Har Nager", 908459781L,"puy123@gmail.com"));
    }
}

